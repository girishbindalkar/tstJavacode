package com.ram.KafkaProducerDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaProducerDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
