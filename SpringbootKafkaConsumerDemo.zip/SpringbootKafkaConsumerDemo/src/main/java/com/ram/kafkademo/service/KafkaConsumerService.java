package com.ram.kafkademo.service;

import com.ram.kafkademo.model.Message;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.ram.kafkademo.model.Animal;

@Service
public class KafkaConsumerService
{
	/*@KafkaListener(topics = "AnimalTopic4", groupId = "test",containerFactory = "animalListener")
	public void listen(Animal animal)
	{
		System.out.println("Received '" + animal +"' from the AnimalTopic." );
	}*/

	/*@KafkaListener(topics = "AnimalTopic4", groupId = "test")
	public void listen(Message message)
	{
		System.out.println("Received '" + message +"' from the AnimalTopic.");
    }*/

	@KafkaListener(topics = "my-atos", groupId = "test", containerFactory = "messageListener")
	public <T> void listen(T message) {
		System.out.println("Received '" + message + "' from the AnimalTopic.");
	}

	@KafkaListener(topics = "my-atos", groupId = "test", containerFactory = "animalGeListener")
	public <T> void listen4(T message) {
		System.out.println("Received '" + message + "' from the AnimalTopic.");
	}

}
