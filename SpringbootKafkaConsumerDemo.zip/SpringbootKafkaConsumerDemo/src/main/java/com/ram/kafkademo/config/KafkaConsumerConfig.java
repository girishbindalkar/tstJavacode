package com.ram.kafkademo.config;

import java.util.HashMap;
import java.util.Map;

import com.ram.kafkademo.model.Animal;
import com.ram.kafkademo.model.Message;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.support.serializer.JsonDeserializer;

@EnableKafka
@Configuration
public class KafkaConsumerConfig
{
	public <T> ConsumerFactory<String, T> consumerFactory(Class<T> valueType) {
		Map<String, Object> config = new HashMap<>();
		config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
		config.put(ConsumerConfig.GROUP_ID_CONFIG, GROUP_ID);
		config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
		config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
		// Use the provided valueType for deserialization
		return new DefaultKafkaConsumerFactory<>(config, new StringDeserializer(), new JsonDeserializer<>(valueType));
	}

	// Creating a Listener
	public <T> ConcurrentKafkaListenerContainerFactory<String, T> kafkaListenerContainerFactory(Class<T> valueType) {
		ConcurrentKafkaListenerContainerFactory<String, T> factory = new ConcurrentKafkaListenerContainerFactory<>();
		factory.setConsumerFactory(consumerFactory(valueType));
		return factory;
	}



	@Bean
	public ConcurrentKafkaListenerContainerFactory<String,Message> messageListener() {
		return kafkaListenerContainerFactory(Message.class); // You can use Object as a generic type
	}


	@Bean
	public ConcurrentKafkaListenerContainerFactory<String,Animal> animalGeListener() {
		return kafkaListenerContainerFactory(Animal.class); // You can use Object as a generic type
	}
	// Example usage for another class type


	// Your GROUP_ID constant
	public static final String GROUP_ID = "test";
}